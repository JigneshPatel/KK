//
//  Utilities.h

#import <Foundation/Foundation.h>


@interface Utilities : NSObject {

}

+(NSString *)bundlePath:(NSString *)fileName;
+(NSString *)documentsPath:(NSString *)fileName;

@end
