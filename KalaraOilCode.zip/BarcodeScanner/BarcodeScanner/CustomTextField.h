//
//  CustomTextField.h
//  Letusmate
//
//  Created by  on 14/01/13.
//
//

#import <UIKit/UIKit.h>

@interface CustomTextField : UITextField

@end
