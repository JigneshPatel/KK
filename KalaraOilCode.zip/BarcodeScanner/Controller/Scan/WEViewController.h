//
//  WEViewController.h
//  WECodeScanner
//
//  Created by Werner Altewischer on 10/11/13.
//  Copyright (c) 2013 Werner IT Consultancy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WEViewController : UIViewController
{
    BOOL look;
    
}

- (IBAction)backButtonAction:(id)sender;

@end
