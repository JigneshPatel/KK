//
//  PCCollectionViewCell.m
//  pizza T
//
//  Created by Gauri Shankar on 22/10/15.
//  Copyright (c) 2015 Urvashi chandan. All rights reserved.
//

#import "PCCollectionViewCell.h"

@implementation PCCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
