//
//  PCCollectionViewCell.h
//  pizza T
//
//  Created by Gauri Shankar on 22/10/15.
//  Copyright (c) 2015 Urvashi chandan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PCCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@property (weak, nonatomic) IBOutlet UILabel *lblName;

@end
