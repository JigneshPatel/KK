//
//  MapDetailVC.h
//  BrandReporter
//
//  Created by Gauri Shankar on 08/08/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapDetailVC : UIViewController
{
    NSString *strLatLong;
    
}

@property(strong,nonatomic) NSString *strLatLong;

@end
