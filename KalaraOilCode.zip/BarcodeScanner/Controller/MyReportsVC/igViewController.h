//
//  igViewController.h
//  ScanBarCodes
//
//  Created by Torrey Betts on 10/10/13.
//  Copyright (c) 2013 Infragistics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface igViewController : UIViewController
{
    BOOL look;

}

- (IBAction)backButtonAction:(id)sender;

@end