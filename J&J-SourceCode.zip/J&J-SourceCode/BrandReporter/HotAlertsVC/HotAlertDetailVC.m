//
//  HotAlertDetailVC.m
//  BrandReporter
//
//  Created by Gauri Shankar on 26/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "HotAlertDetailVC.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"


@interface HotAlertDetailVC ()
{
    IBOutlet UIImageView *imgUser;
    IBOutlet UILabel *lblTitle;
    IBOutlet UITextView *txtDetail;
}
- (IBAction)backButtonAction:(id)sender;

@end

@implementation HotAlertDetailVC

@synthesize dictData;

- (UIStatusBarStyle) preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (IBAction)backButtonAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    imgUser.layer.cornerRadius = imgUser.frame.size.width / 2;
    imgUser.clipsToBounds = YES;
    imgUser.layer.borderWidth = 2.0f;
    imgUser.layer.borderColor = [UIColor lightGrayColor].CGColor;

    //[imgUser setImage:[UIImage imageNamed:dictData[@"thumbnails"]]];

    lblTitle.text = [dictData valueForKey:@"title"];
    txtDetail.text = [dictData valueForKey:@"message"];

    [imgUser
     sd_setImageWithURL:[NSURL URLWithString:dictData[@"thumbnails"]]
     placeholderImage:[UIImage imageNamed:@"TestImg.png"]];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
