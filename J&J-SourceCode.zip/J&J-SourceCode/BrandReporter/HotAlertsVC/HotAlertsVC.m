//
//  HotAlertsVC.m
//  BrandReporter
//
//  Created by Brahmasys on 21/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "HotAlertsVC.h"
#import "NVSlideMenuController.h"
#import "HotAlertsTableViewCell.h"
#import "TeamTrackerDetailVC.h"
#import "HotAlertDetailVC.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"

@interface HotAlertsVC ()<UISearchDisplayDelegate, UISearchBarDelegate>
{
    UIStoryboard *storyboard;
    IBOutlet UISearchBar *searchBarList;
    NSMutableArray *searchData;
    NSMutableArray *inUseArray;

}

@end

@implementation HotAlertsVC

@synthesize  arrList,tblList;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

#pragma mark FOR LEFT MENU ITEM

- (IBAction)backButtonAction:(id)sender {
    
    if (!look)
    {
        [searchBarList resignFirstResponder];
        [self.slideMenuController openMenuAnimated:YES completion:nil];
        
    }
    
    else
    {
        [self.slideMenuController closeMenuAnimated:YES completion:nil];
    }
    
    
    look=!look;
    
}

- (void)viewDidLoad {
    [self.navigationController setNavigationBarHidden:YES];

    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    arrList = [[NSMutableArray alloc] init];
    inUseArray = [[NSMutableArray alloc]init];
    searchData = [[NSMutableArray alloc]init];
    
    /*
    NSDictionary *dictData = @{@"title" : @"Fake Air Jordans", @"message" : @"Hi Team with the release of the new Air Jordans to the makret we have seen a major influx of fakes. Watch out for these fakes, and in particular we have received a tip from US customs that there may be shipments into Long Beach, Create a report immediately if you see anything suspicious.", @"image" : @"Fake Air Jordans.png"};
    [arrList addObject:dictData];
    [inUseArray addObject:dictData];

    dictData = @{@"title" : @"Royal Thai Police Seizure", @"message" : @"Team we are pleased to announce that the Royal Thai Police have worked with Brand Reporter and now seized over $ 1.5 Million in counterfeit apparel products in Bangkok", @"image" : @"Royal Thai Police Seizure.png"};
    [arrList addObject:dictData];
    [inUseArray addObject:dictData];

    dictData = @{@"title" : @"Customs & Border Protection", @"message" : @"Hi team we are pleased to announce that US CBP have seized a massive haul of NFL jerseys. This is all due to great reporting at the field, espiecially in New york in the lead up to the superbowl.", @"image" : @"Customs & Border Protection.png"};
    [arrList addObject:dictData];
    [inUseArray addObject:dictData];

    dictData = @{@"title" : @"New Survey Assigned: 1411 Lincoln Blvd Santa Monica, CA (310) 319-1318", @"message" : @"Please check all Johnson's Baby Powder products for appropriate packaging and placement.", @"image" : @"Johnson's baby Powder.png"};
    [arrList addObject:dictData];
    [inUseArray addObject:dictData];

    dictData = @{@"title" : @"New Survey Assigned: Walgreens, 1496 Market St San Fransisco, CA (415) 626-9972 ", @"message" : @"Please assess the condition of Johnson n Johnson's First Aid Gauze Pad in the above location. Packaging was reported to be sub-optimal.", @"image" : @"Johnson n Johnson's First Aid Gauze Pad.png"};
    [arrList addObject:dictData];
    [inUseArray addObject:dictData];

    dictData = @{@"title" : @"New Survey Assigned: KMart 13007 Sherman Way North Hollywood, CA (818) 764-0250", @"message" : @"Please check all Johnson's Baby Head toToe wash for correct placement. A report shows inadequate placement of these products.", @"image" : @"Johnson Baby Head to Toe wash.png"};
    [arrList addObject:dictData];
    [inUseArray addObject:dictData];


    [tblList reloadData];
    // */
    
    [tblList setBackgroundColor:[UIColor colorWithRed:64.0/255.0f green:200.0/255.0f blue:214.0/255.0f alpha:1.0]];
    
    [self getHotAlerts];
}


#pragma mark API

-(void)getHotAlerts
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Loading....", nil);
    
    NSURL *url = [[NSURL alloc] initWithString:KURLHotAlerts];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         [arrList removeAllObjects];
         [inUseArray removeAllObjects];
         
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         NSLog(@"success: %@", operation.responseString);
         
         NSString *jsonString = operation.responseString;
         NSData *JSONdata = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
         
         NSError *jsonError = nil;
         if (JSONdata != nil) {
             
             arrList = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
             
             inUseArray = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
             
             NSLog(@"arrList %@",arrList);
             
                 [tblList reloadData];
            
             
         }
         else
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"No records found!" delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
             [alert show];
         }
         
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         
         
         
         NSString *errStr=[[error userInfo] objectForKey:@"NSLocalizedDescription"];
         if (errStr==Nil) {
             errStr=@"Server not reachable. Check internet connectivity";
         }
         
         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errStr delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
         [alert show];
         
         
         
     }];
    
    [operation start];
    
}


#pragma mark Table View Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 130;
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [inUseArray count];
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"UserCell";
    
    HotAlertsTableViewCell *cell = (HotAlertsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib;
        
        if (IS_IPHONE_5)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"HotAlertsTableViewCell" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"HotAlertsTableViewCell_i6" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6P)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"HotAlertsTableViewCell_i6P" owner:self options:nil];
            
        }
        else if (IS_IPHONE_4S)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"HotAlertsTableViewCell_4S" owner:self options:nil];
            
        }

        cell = [nib objectAtIndex:0];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    cell.viewWhite.layer.cornerRadius = 3.0f;

    NSDictionary *dictTemp = [inUseArray objectAtIndex:indexPath.row];
    cell.lblTitle.text = [dictTemp valueForKey:@"title"];
    cell.lblSubTitle.text = [dictTemp valueForKey:@"message"];

    cell.imgProduct.layer.cornerRadius = cell.imgProduct.frame.size.width / 2;
    cell.imgProduct.clipsToBounds = YES;
//    cell.imgProduct.layer.borderWidth = 3.0f;
//    cell.imgProduct.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    //[cell.imgProduct setImage:[UIImage imageNamed:dictTemp[@"thumbnails"]]];
    
    [cell.imgProduct
     sd_setImageWithURL:[NSURL URLWithString:dictTemp[@"thumbnails"]]
     placeholderImage:[UIImage imageNamed:@"TestImg.png"]];

    
    tblList.separatorColor = [UIColor clearColor];

    cell.btnHist.tag = indexPath.row;
    
    [cell.btnHist addTarget:self
                     action:@selector(histAction:)
           forControlEvents:UIControlEventTouchUpInside];

    
    return cell;
}

-(void)histAction:(id)sender
{
    storyboard = [AppDelegate storyBoardType];
    HotAlertDetailVC *objVC = (HotAlertDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"HotAlertDetailVCId"];
    objVC.dictData = [inUseArray objectAtIndex:[sender tag]];
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    storyboard = [AppDelegate storyBoardType];
    HotAlertDetailVC *objVC = (HotAlertDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"HotAlertDetailVCId"];
    objVC.dictData = [inUseArray objectAtIndex:indexPath.row];

    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
}

#pragma mark - Search Bar Delegates

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    
    [searchBar resignFirstResponder];
    // Do the search...
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    if ([searchText length] == 0)
    {
        [searchBar performSelector:@selector(resignFirstResponder)
                        withObject:nil
                        afterDelay:0];
    }
    
    [searchData removeAllObjects];// remove all data that belongs to previous search
    
    if([searchText isEqualToString:@""] || searchText==nil)
    {
        NSLog(@"ALL DATA DISPLAY");
        
        inUseArray = arrList;
        
        [searchBar resignFirstResponder];
        [tblList reloadData];
        return;
    }
    
    NSInteger counter = 0;
    
    for(int i=0;i<[arrList count];i++)
    {
        
        
        NSLog(@"--  %d",i);
        
        if([[arrList objectAtIndex:i] isEqual:[NSNull null]])
        {
            NSLog(@"No data add");
            
        }
        else
        {
            NSDictionary *dictData = [arrList objectAtIndex:i];
            
            NSString *name = [dictData valueForKey:@"title"];
            
            if(!name || [name isEqualToString:@""] || [name length]==0)
            {
                NSLog(@"No data");
                NSDictionary *dictData1 = [arrList objectAtIndex:i];
                
                name = [dictData1 valueForKey:@"title"];
            }
            
            NSRange r = [name rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            if(r.location != NSNotFound)
            {
                
                NSDictionary *dictData1 = [arrList objectAtIndex:i];
                
                if(![searchData containsObject:dictData1])
                {
                    [searchData addObject:dictData1];
                }
                NSLog(@"dictData--%@",dictData1);
                
            }
            
            //
            NSString *message = [dictData valueForKey:@"message"];
            
            if(!message || [message isEqualToString:@""] || [message length]==0)
            {
                NSLog(@"No data");
                NSDictionary *dictData1 = [arrList objectAtIndex:i];
                
                message = [dictData1 valueForKey:@"message"];
            }
            
            NSRange rmessage = [message rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            if(rmessage.location != NSNotFound)
            {
                
                NSDictionary *dictData1 = [arrList objectAtIndex:i];
                
                if(![searchData containsObject:dictData1])
                {
                    [searchData addObject:dictData1];
                }
                NSLog(@"dictData--%@",dictData1);
                
            }

            
            counter++;
        }
    }
    
    inUseArray = searchData.mutableCopy;
    
    if([inUseArray count] >0)
    {
        [tblList reloadData];
    }
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    
    for (UIView *subView in searchBar.subviews) {
        if ([subView isKindOfClass:[UIButton class]]) {
            UIButton *cancelButton = (UIButton*)subView;
            [cancelButton setBackgroundImage:Nil forState:UIControlStateNormal];
            
            [cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
        }
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [searchBar resignFirstResponder];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
