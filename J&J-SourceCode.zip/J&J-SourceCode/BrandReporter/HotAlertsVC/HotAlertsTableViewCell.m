//
//  HotAlertsTableViewCell.m
//  BrandReporter
//
//  Created by Brahmasys on 23/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "HotAlertsTableViewCell.h"

@implementation HotAlertsTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
