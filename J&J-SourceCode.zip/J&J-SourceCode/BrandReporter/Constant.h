//
//  Constant.h
//  BrandReporter
//
//  Created by Gauri Shankar on 19/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#ifndef BrandReporter_Constant_h
#define BrandReporter_Constant_h

#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_RETINA ([[UIScreen mainScreen] scale] >= 2.0)

#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))

#define IS_IPHONE_4S (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
#define IS_IPHONE_5 (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
#define IS_IPHONE_6 (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
#define IS_IPHONE_6P (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)

//#define kGooglePlacesAPIBrowserKey @"AIzaSyAdIoz7SMgZ1ovpHyvGMOXfbTUz96h5fuI"
#define kGooglePlacesAPIBrowserKey @"AIzaSyCbCPKyD0u0isJxPzNG_4rTq_1jOYuD_aA"

#define TimeStamp [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000]

#define KBaseUrl @"http://brandreporter.co/"

#define KURLBarCode  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=get-report"

#define KURLSignIn  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=login"

#define KURLSignUp  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=register"

#define KURLForgotPwd  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=forgotpass"

#define KURLProfile  @"http://brandreporter.co/webservice/brandreporter.php?action=profile"

#define KURLProfileEdit  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=editpro"

#define KURLSubmitReport  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=submit_report"

#define KURLDeleteReport  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=DeleteParticularReport&MyReportId="

//http://www.support-4-pc.com/clients/jandj/subscriber.php?action=get-report

//http://www.support-4-pc.com/clients/jandj/subscriber.php?action=report_detail&user_name=

#define KURLMyReports  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=get-report"

#define KURLMyReportsDetail  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=report_detail&userid="

#define KURLNotifications  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=getnotification"

#define KURLTeamReports  @"http://brandreporter.co/team_reports_mobile.php"

#define KURLTeamReportsDetail  @"http://brandreporter.co/report_details_ios_mobile.php?id="

#define KURLTeamTracker  @"http://brandreporter.co/webservice/new_webservice.php?action=team_tracker"

#define KURLTeamTrackerDetail  @"http://brandreporter.co/webservice/new_webservice.php?action=team_tracker_detail"

#define KURLHotAlerts  @"http://brandreporter.co/webservice/new_webservice.php?action=hot_alerts"

#define KURLHotAlertsDetail  @"http://brandreporter.co/webservice/new_webservice.php?action=hot_alerts_detail"

#define KURLKnowledgeLib  @"http://brandreporter.co/webservice/new_webservice.php?action=knowladge_library"

#define KURLKnowledgeLibDetail  @"http://brandreporter.co/webservice/new_webservice.php?action=knowladge_library_detail"

//New API

#define KURLGetSurvey  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=getsurvey"

#define KURLGetSurveyQuestion  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=survey_question"

#define KURLSubmitSurvey  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=submit_survey"

#define KURLGetDraft  @"http://www.support-4-pc.com/clients/jandj/subscriber.php?action=getdraft"

#endif

#define kLoggedInUserId @"LoggedInUserId"
#define kLoggedInUserPwd @"LoggedInUserPwd"
#define kLoggedInUserName @"LoggedInUserName"
#define kLoggedInUserEmail @"LoggedInUserEmail"
#define kLoggedInUserImage @"LoggedInUserImage"


