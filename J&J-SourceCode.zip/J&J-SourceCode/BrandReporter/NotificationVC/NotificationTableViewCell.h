//
//  NotificationTableViewCell.h
//  BrandReporter
//
//  Created by Gauri Shankar on 23/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationTableViewCell : UITableViewCell

@property (weak, nonatomic)     IBOutlet UIImageView *imgProduct;

@property (weak, nonatomic)     IBOutlet UILabel *lblTitle,*lblDate;

@end
