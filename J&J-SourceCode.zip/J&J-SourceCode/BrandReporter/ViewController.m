//
//  ViewController.m
//  BrandReporter
//
//  Created by Gauri Shankar on 19/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "ViewController.h"
#import "RegisterVCViewController.h"
#import "AppDelegate.h"
#import "ForgotVC/ForgotViewController.h"
#import "MyReportsVC.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "TPKeyboardAvoidingScrollView.h"

@interface ViewController ()<UITextFieldDelegate,UIScrollViewDelegate>
{
    UIStoryboard *storyboard;
    IBOutlet UITextField *txtUserName,*txtPassword;
}

@end

@implementation ViewController

@synthesize scrollView;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [self.navigationController setNavigationBarHidden:YES];
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [scrollView contentSizeToFit];
    
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView1 willDecelerate:(BOOL)decelerate
{
    CGPoint offset = scrollView1.contentOffset;
    [scrollView1 setContentOffset:offset animated:NO];
    
    
}

/*
-(IBAction)registerButtonAction:(id)sender
{
    storyboard = [AppDelegate storyBoardType];
    RegisterVCViewController *objVC = (RegisterVCViewController*)[storyboard instantiateViewControllerWithIdentifier:@"RegisterVCViewControllerId"];
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;

}
*/

-(IBAction)signInButtonAction:(id)sender
{
    [self MoveToUserProfileView];

    
}

-(void)MoveToUserProfileView
{
    
    [txtUserName resignFirstResponder];
    if (txtUserName.text!=Nil) {
        if ([txtUserName.text length]>0)
        {
            NSLog(@"%@ is a User id",txtUserName.text);
            if (txtPassword.text!=Nil) {
                if ([txtPassword.text length]>0)
                {
                    NSLog(@"%@ is a Password",txtPassword.text);
                    [self loginValidation];
                }
                else{
                    
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please check the password." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    [alert show];
                }
                
            }
            else{
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please check the password." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alert show];
              }
            
        }
        else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please check the username." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
        
        }
        
    }
    else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please check the username." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
}


#pragma mark LOGIN API

-(void)loginValidation
{
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Processing Login", nil);

    txtUserName.text = [txtUserName.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    //username,password
    
    NSURL *url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"%@&&email=%@&&pass=%@",KURLSignIn,txtUserName.text,txtPassword.text]];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        NSLog(@"success: %@", operation.responseString);
        NSString *jsonString = operation.responseString;
        NSData *JSONdata = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        NSError *jsonError = nil;
        if (JSONdata != nil) {


            NSMutableDictionary *DiccL = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
            
            NSLog(@"Dicc: %@", DiccL);
            
            
            if ([[DiccL objectForKey:@"result"] intValue] ==0)
            {
                
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alert show];
            }
            else
            {
                
                NSLog(@"User is logged in");
                
                NSArray *arr = [DiccL objectForKey:@"response"];
                
                NSDictionary *dict = [arr objectAtIndex:0];
                
                [defaults setObject:[dict valueForKey:@"username"] forKey:kLoggedInUserName];
                [defaults setObject:[dict valueForKey:@"id"] forKey:kLoggedInUserId];
                [defaults setObject:[dict valueForKey:@"email"] forKey:kLoggedInUserEmail];
                [defaults setObject:[dict valueForKey:@"image"] forKey:kLoggedInUserImage];

                [defaults synchronize];
                
                
                //
                storyboard = [AppDelegate storyBoardType];
                MyReportsVC *objVC = (MyReportsVC*)[storyboard instantiateViewControllerWithIdentifier:@"MyReportsVCId"];
                
                [self.navigationController pushViewController:objVC animated:YES];
                objVC = nil;
            }
            
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Login Failed." message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
        }
        
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSLog(@"error: %@",  operation.responseString);
        
        
        NSString *errStr=[[error userInfo] objectForKey:@"NSLocalizedDescription"];
        if (errStr==Nil) {
            errStr=@"Server not reachable";
        }
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errStr delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
        [alert show];
        
        
    }];
    
    [operation start];
    
}



-(IBAction)forgotPwdButtonAction:(id)sender
{
    
    storyboard = [AppDelegate storyBoardType];
    ForgotViewController *objVC = (ForgotViewController*)[storyboard instantiateViewControllerWithIdentifier:@"ForgotViewControllerId"];
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
