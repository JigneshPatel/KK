//
//  TeamTrackerDetailTableViewCell.h
//  BrandReporter
//
//  Created by Gauri Shankar on 15/08/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamTrackerDetailTableViewCell : UITableViewCell

@property (weak, nonatomic)     IBOutlet UIButton *btnHist;
@property (weak, nonatomic)     IBOutlet UIView *viewWhite;

@end
