//
//  TeamTrackerVC.m
//  BrandReporter
//
//  Created by Brahmasys on 21/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "TeamTrackerVC.h"
#import "NVSlideMenuController.h"
#import "TeamTrackerTableViewCell.h"
#import "AppDelegate.h"
#import "TeamTrackerDetailVC.h"
#import "Constant.h"
#import "MBProgressHUD.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "MapDetailVC.h"

@interface TeamTrackerVC ()<UISearchDisplayDelegate, UISearchBarDelegate>
{
    UIStoryboard *storyboard;
    IBOutlet UISearchBar *searchBarList;
}
@end

@implementation TeamTrackerVC

@synthesize  arrList,tblList;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

#pragma mark FOR LEFT MENU ITEM

- (IBAction)backButtonAction:(id)sender {
    
    if (!look)
    {
        [searchBarList resignFirstResponder];
        
        [self.slideMenuController openMenuAnimated:YES completion:nil];
        
    }
    
    else
    {
        [self.slideMenuController closeMenuAnimated:YES completion:nil];
    }
    
    look=!look;
    
}

- (void)viewDidLoad {
    [self.navigationController setNavigationBarHidden:YES];

    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [tblList setBackgroundColor:[UIColor colorWithRed:64.0/255.0f green:200.0/255.0f blue:214.0/255.0f alpha:1.0]];

    arrList = [[NSMutableArray alloc] init];
    
    /*
    NSDictionary *dictData = @{@"title" : @"Harry Cuban", @"subtitle" : @"harry@ypbsystems.com", @"image" : @"Harry Cuban.png"};
    [arrList addObject:dictData];
    
    dictData = @{@"title" : @"Daniel Craig", @"subtitle" : @"daniel@ypbsystems.com", @"image" : @"Daniel Craig.png"};
    [arrList addObject:dictData];
    
    dictData = @{@"title" : @"William Hill", @"subtitle" : @"william@ypbsystems.com", @"image" : @"William Hill.png"};
    [arrList addObject:dictData];
    
    dictData = @{@"title" : @"John Oliver", @"subtitle" : @"john@ypbsystems.com", @"image" : @"John Oliver.png"};
    [arrList addObject:dictData];
    
    dictData = @{@"title" : @"Mark Levin", @"subtitle" : @"mark@ypbsystems.com", @"image" : @"Mark Levin.png"};
    [arrList addObject:dictData];
    
    [tblList reloadData];
     */
    
    [self getTeamTracker];
}

#pragma mark API

-(void)getTeamTracker
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Loading....", nil);
    
    NSURL *url = [[NSURL alloc] initWithString:KURLTeamTracker];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         [arrList removeAllObjects];
         
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         NSLog(@"success: %@", operation.responseString);
         
         NSString *jsonString = operation.responseString;
         NSData *JSONdata = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
         
         NSError *jsonError = nil;
         if (JSONdata != nil) {
             
             arrList = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
             
            [tblList reloadData];
             
         }
         else
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"No records found!" delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
             [alert show];
         }
         
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         
         
         
         NSString *errStr=[[error userInfo] objectForKey:@"NSLocalizedDescription"];
         if (errStr==Nil) {
             errStr=@"Server not reachable. Check internet connectivity";
         }
         
         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errStr delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
         [alert show];
         
         
         
     }];
    
    [operation start];
    
}

#pragma mark Table View Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 140;
    
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [arrList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"UserCell";
    
    TeamTrackerTableViewCell *cell = (TeamTrackerTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib;
        
        if (IS_IPHONE_5)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamTrackerTableViewCell" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamTrackerTableViewCell_i6" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6P)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamTrackerTableViewCell_i6P" owner:self options:nil];
            
        }else if (IS_IPHONE_4S)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamTrackerTableViewCell_4s" owner:self options:nil];
            
        }

        cell = [nib objectAtIndex:0];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    cell.viewWhite.layer.cornerRadius = 3.0f;

    NSDictionary *dictTemp = [arrList objectAtIndex:indexPath.row];
    cell.lblTitle.text = dictTemp[@"user_name"];
    cell.txtAddress.text = dictTemp[@"address"];
    
    NSString *strImg = dictTemp[@"location_date"];
    
    NSArray *arrImg = [strImg componentsSeparatedByString:@" "];
    NSLog(@"arrImg %@",arrImg);
    cell.lblTime.text = [arrImg objectAtIndex:1];

    cell.lblDate.text = [arrImg objectAtIndex:0];
    
    cell.imgProduct.layer.cornerRadius = cell.imgProduct.frame.size.width / 2;
    cell.imgProduct.clipsToBounds = YES;

    [cell.imgProduct
     sd_setImageWithURL:[NSURL URLWithString:@""]
     placeholderImage:[UIImage imageNamed:@"TestImg.png"]];
    
    tblList.separatorColor = [UIColor clearColor];
    
    cell.btnHist.tag = indexPath.row;

    [cell.btnHist addTarget:self
                     action:@selector(histAction:)
       forControlEvents:UIControlEventTouchUpInside];

    
    return cell;
}

-(void)histAction:(id)sender
{
    NSLog(@"load map view ");
    
    storyboard = [AppDelegate storyBoardType];
    
    MapDetailVC *objVC = (MapDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"MapDetailVCId"];
    objVC.strLatLong = [[arrList objectAtIndex:[sender tag]] valueForKey:@"geo"];
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    storyboard = [AppDelegate storyBoardType];
//    TeamTrackerDetailVC *objVC = (TeamTrackerDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"TeamTrackerDetailVCId"];
//    objVC.dictData = [arrList objectAtIndex:indexPath.row];
//
//    [self.navigationController pushViewController:objVC animated:YES];
//    objVC = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
