//
//  TeamTrackerDetailVC.m
//  BrandReporter
//
//  Created by Gauri Shankar on 26/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "TeamTrackerDetailVC.h"
#import "TeamTrackerDetailTableViewCell.h"
#import "MapDetailVC.h"
#import "AppDelegate.h"
#import "Constant.h"


@interface TeamTrackerDetailVC ()<UITableViewDataSource,UITableViewDelegate>
{
    BOOL look;
    IBOutlet UITableView *tblList;
    NSMutableArray *arrList;
    IBOutlet UILabel *lblName,*lblDate,*lblAddress;
    UIStoryboard *storyboard;
        
}

- (IBAction)backButtonAction:(id)sender;

@end

@implementation TeamTrackerDetailVC

@synthesize dictData;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (IBAction)backButtonAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)viewDidLoad {
    [self.navigationController setNavigationBarHidden:YES];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    arrList = [[NSMutableArray alloc] init];//]WithObjects:@"Gauri",@"",@"",@"",@"",@"",@"", nil];
    
    //[tblList reloadData];
    
    lblName.text = [dictData valueForKey:@"user_name"];
    lblDate.text = [dictData valueForKey:@"location_date"];
    lblAddress.text = [dictData valueForKey:@"address"];

}

#pragma mark Table View Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 140;
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [arrList count];
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"UserCell";
    
    TeamTrackerDetailTableViewCell *cell = (TeamTrackerDetailTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        
        NSArray *nib;
        
        if (IS_IPHONE_5)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamTrackerDetailTableViewCell" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamTrackerDetailTableViewCell_i6" owner:self options:nil];
            
        }
        
        cell = [nib objectAtIndex:0];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    cell.viewWhite.layer.cornerRadius = 3.0f;

    [cell.btnHist addTarget:self
                     action:@selector(mapButtonAction:)
           forControlEvents:UIControlEventTouchUpInside];
    
    //    cell.imgUser.layer.cornerRadius = 9.0f;
    //    cell.imgUser.layer.borderWidth = 2.0f;
    //    cell.imgUser.clipsToBounds = YES;
    //    cell.imgUser.layer.borderColor = [UIColor whiteColor].CGColor;
    //    [cell.imgUser setFrame:CGRectMake(10, 10, 50, 50)];
    //
    //    cell.lblFNLN.text = @"Name";
    //
    //    cell.lblUN.text = @"username";
    
    return cell;
}

- (IBAction)mapButtonAction:(id)sender
{
    NSLog(@"load map view ");
    
    storyboard = [AppDelegate storyBoardType];
    
    MapDetailVC *objVC = (MapDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"MapDetailVCId"];
    objVC.strLatLong = [dictData valueForKey:@"geo"];
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
    
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    storyboard = [AppDelegate storyBoardType];
    
    MapDetailVC *objVC = (MapDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"MapDetailVCId"];
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
    
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
