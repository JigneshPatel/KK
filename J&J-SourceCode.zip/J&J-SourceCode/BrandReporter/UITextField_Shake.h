//
//  UITextField+Shake.h
//  UITextField+Shake
//
//  Created by Andrea Mazzini on 24/07/15.
//  Copyright (c) 2015 Fancy Pixel. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UITextField+Shake.
FOUNDATION_EXPORT double UITextField_ShakeVersionNumber;

//! Project version string for UITextField+Shake.
FOUNDATION_EXPORT const unsigned char UITextField_ShakeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UITextField_Shake/PublicHeader.h>
//#import <UITextField_Shake/UITextField+Shake.h>

