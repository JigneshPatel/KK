//
//  AppDelegate.h
//  BrandReporter
//
//  Created by Gauri Shankar on 19/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideMenu.h"
#import "NVSlideMenuController.h"

@import MapKit;
@import CoreLocation;

@interface AppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate>
{
    UINavigationController *navController;
    NSMutableArray *arrMyReports;
    NSMutableDictionary *dictRecord;
    NSString *path;
    NSMutableDictionary *dictPlistDealsData;
    int intEditReport;
}

@property int intEditReport;

@property (strong, nonatomic) NSMutableDictionary *dictRecord;

@property (strong, nonatomic) NSMutableArray *arrMyReports;
@property (strong, nonatomic) NSString *path;
@property(nonatomic,retain)NSMutableDictionary *dictPlistDealsData;

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSMutableString *AD_user_uid;
@property (strong, nonatomic) CLLocationManager *manager;
@property (strong, nonatomic) CLLocation *cLocation;

+ (AppDelegate *)sharedAppDelegate;
+ (UIStoryboard *)storyBoardType;
+ (UIImage*)getImage:(NSString *)strImageName fromFolder:(NSString *)strFolderName;

@end

