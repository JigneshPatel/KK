//
//  MyCell.h

#import <UIKit/UIKit.h>

@interface MyCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@property (weak, nonatomic) IBOutlet UIButton *btnCross;


@end
