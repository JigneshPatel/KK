//
//  AboutUsViewController.h
//  BrandReporter
//
//  Created by Gauri Shankar on 10/10/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsViewController : UIViewController
{
    BOOL look;

}
-(IBAction)PPButtonAction:(id)sender;
-(IBAction)TCButtonAction:(id)sender;

@end
