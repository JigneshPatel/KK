//
//  AboutUsViewController.m
//  BrandReporter
//
//  Created by Gauri Shankar on 10/10/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "AboutUsViewController.h"
#import "TCViewController.h"
#import "PPViewController.h"
#import "NVSlideMenuController.h"
#import "AppDelegate.h"

@interface AboutUsViewController ()
{
    UIStoryboard *storyboard;

}
@end

@implementation AboutUsViewController
- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

#pragma mark FOR LEFT MENU ITEM

- (IBAction)backButtonAction:(id)sender {
    
    if (!look)
    {
        [self.slideMenuController openMenuAnimated:YES completion:nil];
        
    }
    
    else
    {
        [self.slideMenuController closeMenuAnimated:YES completion:nil];
    }
    
    
    look=!look;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:YES];

}

-(IBAction)PPButtonAction:(id)sender
{
    storyboard = [AppDelegate storyBoardType];
    PPViewController *objVC = (PPViewController*)[storyboard instantiateViewControllerWithIdentifier:@"PPViewControllerId"];
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
 
}
-(IBAction)TCButtonAction:(id)sender
{
    storyboard = [AppDelegate storyBoardType];
    TCViewController *objVC = (TCViewController*)[storyboard instantiateViewControllerWithIdentifier:@"TCViewControllerId"];
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
 
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
