//
//  Request.h
//  PASSENGER
//
//  Created by vikas on 24/08/15.
//  Copyright (c) 2015 Avigma. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@protocol RequestDelegate<NSObject>

-(void)getResult:(id)response;
-(void)getError;


@end

@interface Request : NSObject
@property(nonatomic,weak) id<RequestDelegate> delegate;



@property(nonatomic,strong) NSURLConnection *urlConnecction;
@property(nonatomic,strong) NSMutableData *webData;



-(void)signUp:(NSString *)name surname:(NSString *)surname email:(NSString *)email password:(NSString *)password profilePic:(NSString *)profilePic dob:(NSString *)dob nationality:(NSString *)nationality gender:(NSString*)gender withDeviceToken:(NSString*)tokken;

-(void)editProfile:(NSString *)name surname:(NSString *)surname email:(NSString *)email  profilePic:(NSString *)profilePic dob:(NSString *)dob nationality:(NSString *)nationality  withDeviceToken:(NSString*)tokken;

-(void)createEvent:(NSString *)event_name event_location:(NSString *)event_location event_date:(NSString *)event_date event_type:(NSString *)event_type event_image:(NSString *)event_image additional_images:(NSString *)additional_images event_description:(NSString *)event_description event_additional_info
                  :(NSString *)event_additional_info
   withDeviceToken:(NSString*)tokken;

-(void)signUpWithMultipart:(NSString *)name name:(NSString *)surname password:(NSString *)email profilePic:(NSData *)profilePic;

-(void)loginWithUserName:(NSString *)userName withPassword:(NSString *)password;

-(void)resetPasswordWithEmail:(NSString *)email;



@end
