//
//  RegisterVCViewController.m
//  BrandReporter
//
//  Created by Gauri Shankar on 19/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "RegisterVCViewController.h"
#import "AppDelegate.h"
#import "MyReportsVC.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "TPKeyboardAvoidingScrollView.h"


@interface RegisterVCViewController ()<UITextFieldDelegate,UIActionSheetDelegate,NSURLConnectionDataDelegate,NSURLConnectionDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIScrollViewDelegate>
{
    UIStoryboard *storyboard;
    IBOutlet UITextField *txtEmail,*txtPwd,*txtCPwd,*txtUserName;
    IBOutlet UIImageView *imgPic,*imgAvt;
    IBOutlet UILabel *lblAvt;
    NSURLConnection *serverConnection;
    NSMutableData *returnData;
}

-(IBAction)picButtonAction:(id)sender;


@end

@implementation RegisterVCViewController

@synthesize scrollView;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    imgPic.layer.cornerRadius = imgPic.frame.size.width / 2;
    imgPic.clipsToBounds = YES;
//    imgPic.layer.borderWidth = 3.0f;
//    imgPic.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    [scrollView contentSizeToFit];

}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView1 willDecelerate:(BOOL)decelerate
{
    CGPoint offset = scrollView1.contentOffset;
    [scrollView1 setContentOffset:offset animated:NO];
    
    
}


-(IBAction)registerButtonAction:(id)sender
{
    [self submitRegisgter];

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
}

-(IBAction)cancelButtonAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)picButtonAction:(id)sender
{
    NSLog(@"pic selection");
    
        UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @" Gallery", nil];
        [sheet showInView:self.view];
        [sheet setTag:1];
}

-(void)hideAvt
{
    [imgAvt setHidden:YES];
    [lblAvt setHidden:YES];

}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if(buttonIndex==actionSheet.cancelButtonIndex){
        return;
    }
    
        if (buttonIndex==0)
        {
            UIImagePickerController *profile_ImagePicker = [[UIImagePickerController alloc]init];
            
            profile_ImagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [profile_ImagePicker setDelegate:self];
            
            [self presentViewController:profile_ImagePicker animated:YES completion:nil];
        }
        else if (buttonIndex==1)
        {

            UIImagePickerController *profile_ImagePicker = [[UIImagePickerController alloc]init];
            
            profile_ImagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [profile_ImagePicker setDelegate:self];
            
            [self presentViewController:profile_ImagePicker animated:YES completion:nil];
        }
    
}

#pragma mark Image Picker Controller

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    
    
    UIGraphicsBeginImageContext(CGSizeMake(400,400));
    [image drawInRect:CGRectMake(0,0,400,400)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    NSData *imgData1 = UIImageJPEGRepresentation(newImage, 0.5); //1 it represents the quality of the image.
    NSLog(@"Size of Image(bytes):%lu",(unsigned long)[imgData1 length]);
    
    UIImage *imgNew = [UIImage imageWithData:imgData1];
    
    if(image != nil)
    {
        [self hideAvt];
    }
    
    imgPic.image = imgNew;//[UIImage imageWithData:data];
    
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}


#pragma mark TextField Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
   
    [textField resignFirstResponder];
    
    return YES;
}

-(BOOL)isEmail:(NSString*)inputString
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:txtEmail.text];
    
}

#pragma mark API


-(void)submitRegisgter
{
   
    if(![self isEmail:txtEmail.text])
    {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Please provide valid email address!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        alert=nil;
        return;

    }
    else if([txtEmail.text length]==0 || [txtUserName.text length]==0 || [txtPwd.text length]==0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Please check the email/password." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        alert=nil;
        return;

    }
    else if (![txtPwd.text isEqualToString:txtCPwd.text])
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Password not match" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        alert=nil;
        
        return;
        
    }
    else
    {
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://brandreporter.co/webservice/brandreporter.php?action=sign_up"]];
    
    NSData *imageData = UIImageJPEGRepresentation(imgPic.image, 1.0);
    
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:60];
    [request setHTTPMethod:@"POST"];
    
    NSString *boundary = @"unique-consistent-string";
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=%@\r\n\r\n", @"user_name"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n",txtUserName.text] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // add params (all params are strings)
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=%@\r\n\r\n", @"email"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n",txtEmail.text] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // add params (all params are strings)
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=%@\r\n\r\n", @"password"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n",txtPwd.text] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // add image data
    
    int timestamp = [[NSDate date] timeIntervalSince1970];
    NSString *imageName = [NSString stringWithFormat:@"%d",timestamp];
    
    if (imageData) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=%@; filename=%@.png\r\n", @"image",imageName] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:imageData];
        [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set the content-length
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Processing....", nil);
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue currentQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
    {
        if(data.length > 0)
        {
            //success
            NSLog(@"success");
            
            [MBProgressHUD hideHUDForView:self.view animated:YES];

            NSError *jsonError = nil;
            if (data != nil) {
                
                NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
                
                NSMutableDictionary *resDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                
                if ([[resDic objectForKey:@"result"] intValue] ==0)
                {
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    [alert show];
                }
                else
                {
                    
                    NSArray *arr = [resDic objectForKey:@"response"];
                    
                    NSDictionary *dict = [arr objectAtIndex:0];
                    
                    [defaults setObject:txtUserName.text forKey:kLoggedInUserName];
                    [defaults setObject:txtPwd.text forKey:kLoggedInUserPwd];
                    [defaults setObject:[dict valueForKey:@"id"] forKey:kLoggedInUserId];
                    [defaults setObject:[dict valueForKey:@"email"] forKey:kLoggedInUserEmail];
                    [defaults setObject:[dict valueForKey:@"image"] forKey:kLoggedInUserImage];
                    
                    [defaults synchronize];
                    
                    storyboard = [AppDelegate storyBoardType];
                    MyReportsVC *objVC = (MyReportsVC*)[storyboard instantiateViewControllerWithIdentifier:@"MyReportsVCId"];
                    
                    [self.navigationController pushViewController:objVC animated:YES];
                    objVC = nil;
                }
                
            } else {
                
                
            }

            /*
             
             */
        }
    }];
    }
    
}


- (NSString*)base64forData:(NSData*) theData {
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    table[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
