//
//  KnowledgeDetailVC.h
//  BrandReporter
//
//  Created by Gauri Shankar on 26/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KnowledgeDetailVC : UIViewController
{
    NSDictionary *dictData;
}

@property (strong, nonatomic) NSDictionary *dictData;

@end
