//
//  TeamReportsTableViewCell.h
//  BrandReporter
//
//  Created by Brahmasys on 23/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamReportsTableViewCell : UITableViewCell

@property (weak, nonatomic)     IBOutlet UILabel *lblReporter,*lblStatus,*lblProduct;
@property (weak, nonatomic)     IBOutlet UIImageView *imgProduct;
@property (weak, nonatomic)     IBOutlet UIButton *btnHist;
@property (weak, nonatomic)     IBOutlet UIView *viewWhite;

@end
