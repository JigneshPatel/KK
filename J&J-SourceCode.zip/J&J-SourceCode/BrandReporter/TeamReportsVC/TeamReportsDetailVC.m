//
//  TeamReportsDetailVC.m
//  BrandReporter
//
//  Created by Gauri Shankar on 26/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "TeamReportsDetailVC.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "MapDetailVC.h"
#import "AppDelegate.h"

@interface TeamReportsDetailVC ()
{
    UIStoryboard *storyboard;

    IBOutlet UIImageView *imgViewReport;
    IBOutlet UILabel *lblReporter,*lblReportDate,*lblReportStatus,*lblBarCode,*lblMft,*lblBrand,*lblProduct,*lblSize,*lblAdd,*lblComment;
    NSString *strLatLong;
}

- (IBAction)backButtonAction:(id)sender;
- (IBAction)mapButtonAction:(id)sender;

@end

@implementation TeamReportsDetailVC

@synthesize strTRId;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    imgViewReport.layer.cornerRadius = imgViewReport.frame.size.width / 2;
    imgViewReport.clipsToBounds = YES;
    imgViewReport.layer.borderWidth = 2.0f;
    imgViewReport.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    
    [self getTeamReports];
    
}


-(void)getTeamReports
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Loading....", nil);
    
    NSURL *url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"%@%@",KURLTeamReportsDetail,strTRId]];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSLog(@"success: %@", operation.responseString);
        
        NSString *jsonString = operation.responseString;
        NSData *JSONdata = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        
        NSError *jsonError = nil;
        if (JSONdata != nil) {
            
            NSMutableDictionary *resDic = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
            
            NSArray *arrData = [resDic objectForKey:@"data"];
            
            NSDictionary *dictReport = [arrData objectAtIndex:0];
            
            //{"data":[{"user_name":"jack","created_date":"2015-07-25 01:33:47","status":"Verified","barcode":"312547427951","manufacturer":"","brand":"Listerine","product":"cool mint mouth wash","size":"3.2 oz","address":"3471,W 5th St,Los Angeles,California,90020","thumbnail":"report_images\/jack_mobile_cmn6a3o6.jpg","geo":"34.0653935,-118.2948566","lat":"34.0653935","lon":"-118.2948566","comment":"Fake"}]}
            
            lblReporter.text = [dictReport valueForKey:@"user_name"];
            lblReportDate.text = [dictReport valueForKey:@"created_date"];
            
            lblReportStatus.text = [dictReport valueForKey:@"status"];
            lblBarCode.text = [dictReport valueForKey:@"barcode"];
            lblMft.text = [dictReport valueForKey:@"manufacturer"];
            lblBrand.text = [dictReport valueForKey:@"brand"];
            lblProduct.text = [dictReport valueForKey:@"product"];
            lblSize.text = [dictReport valueForKey:@"size"];
            lblAdd.text = [dictReport valueForKey:@"address"];
            lblComment.text = [dictReport valueForKey:@"comment"];
            
            strLatLong = [NSString stringWithFormat:@"%@,%@",[dictReport valueForKey:@"lat"],[dictReport valueForKey:@"lon"]];
            
            NSLog(@"strLatLong %@",strLatLong);
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^(void) {
                
                NSString *profileURL = [KBaseUrl stringByAppendingPathComponent:[dictReport valueForKey:@"thumbnail"]];
                
                [imgViewReport
                 sd_setImageWithURL:[NSURL URLWithString:profileURL]
                 placeholderImage:[UIImage imageNamed:@"no_image.png"]];
            });
        
            
            
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        
        
        NSString *errStr=[[error userInfo] objectForKey:@"NSLocalizedDescription"];
        if (errStr==Nil) {
            errStr=@"Server not reachable. Check internet connectivity";
        }
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errStr delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
        [alert show];
        
        
        
    }];
    
    [operation start];
    
}

- (IBAction)backButtonAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)mapButtonAction:(id)sender
{
    NSLog(@"load map view %@",strLatLong);
    
    storyboard = [AppDelegate storyBoardType];
    
    MapDetailVC *objVC = (MapDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"MapDetailVCId"];
    objVC.strLatLong = strLatLong;
    
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
