//
//  TeamReportsVC.m
//  BrandReporter
//
//  Created by Brahmasys on 21/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "TeamReportsVC.h"
#import "NVSlideMenuController.h"
#import "TeamReportsTableViewCell.h"
#import "AppDelegate.h"
#import "TeamReportsDetailVC.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"


@interface TeamReportsVC ()<UISearchDisplayDelegate, UISearchBarDelegate>
{
    UIStoryboard *storyboard;
    IBOutlet UISearchBar *searchBarList;
    NSMutableArray *searchData;
    NSMutableArray *inUseArray;

}
@end

@implementation TeamReportsVC

@synthesize arrList;


- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

#pragma mark FOR LEFT MENU ITEM

- (IBAction)backButtonAction:(id)sender
{
    [searchBarList resignFirstResponder];
    
    if (!look)
    {
        [self.slideMenuController openMenuAnimated:YES completion:nil];
    }
    else
    {
        [self.slideMenuController closeMenuAnimated:YES completion:nil];
    }
    
    look=!look;
    
}

- (void)viewDidLoad
{
    [self.navigationController setNavigationBarHidden:YES];
    arrList = [[NSMutableArray alloc] init];
    searchData = [[NSMutableArray alloc]init];
    inUseArray = [[NSMutableArray alloc]init];

    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [tblList setBackgroundColor:[UIColor colorWithRed:64.0/255.0f green:200.0/255.0f blue:214.0/255.0f alpha:1.0]];

    [self getTeamReports];
}

#pragma mark Table View Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 90;
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [inUseArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"UserCell";
    
    TeamReportsTableViewCell *cell = (TeamReportsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        
        NSArray *nib;
        
        if (IS_IPHONE_5)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamReportsTableViewCell" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamReportsTableViewCell_i6" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6P)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamReportsTableViewCell_i6P" owner:self options:nil];
            
        }
        else if (IS_IPHONE_4S)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"TeamReportsTableViewCell_4S" owner:self options:nil];
            
        }

        cell = [nib objectAtIndex:0];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    cell.viewWhite.layer.cornerRadius = 3.0f;

    NSDictionary *dictTemp = [inUseArray objectAtIndex:indexPath.row];

    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
    dispatch_async(queue, ^(void) {

    NSString *profileURL = [KBaseUrl stringByAppendingPathComponent:[dictTemp valueForKey:@"thumbnail"]];
        
    [cell.imgProduct
     sd_setImageWithURL:[NSURL URLWithString:profileURL]
     placeholderImage:[UIImage imageNamed:@"no_image.png"]];
     });
    
    cell.lblProduct.text = [dictTemp valueForKey:@"product"];
    cell.lblReporter.text = [dictTemp valueForKey:@"brand"];
    //        status = "<font color=\"#59B200\">Verified</font>";

    //NSString *strImg = dictTemp[@"status"];
    
   // NSArray *arrImg = [strImg componentsSeparatedByString:@">"];
   // NSLog(@"arrImg %@",arrImg);
    
    
    cell.lblStatus.text = @"Verified";//[arrImg objectAtIndex:1];
    
    cell.imgProduct.layer.cornerRadius = cell.imgProduct.frame.size.width / 2;
    cell.imgProduct.clipsToBounds = YES;
    
    tblList.separatorColor = [UIColor clearColor];

    cell.btnHist.tag = indexPath.row;
    
    [cell.btnHist addTarget:self
                     action:@selector(histAction:)
           forControlEvents:UIControlEventTouchUpInside];
    
    
    return cell;
}

-(void)histAction:(id)sender
{
    storyboard = [AppDelegate storyBoardType];
    TeamReportsDetailVC *objVC = (TeamReportsDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"TeamReportsDetailVCId"];
    objVC.strTRId = [[inUseArray objectAtIndex:[sender tag]] valueForKey:@"id"];
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    storyboard = [AppDelegate storyBoardType];
    TeamReportsDetailVC *objVC = (TeamReportsDetailVC*)[storyboard instantiateViewControllerWithIdentifier:@"TeamReportsDetailVCId"];
    objVC.strTRId = [[inUseArray objectAtIndex:indexPath.row] valueForKey:@"id"];
    [self.navigationController pushViewController:objVC animated:YES];
    objVC = nil;
}


-(void)getTeamReports
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Loading....", nil);
    
    NSURL *url = [[NSURL alloc] initWithString:KURLTeamReports];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSLog(@"success: %@", operation.responseString);
        
        NSString *jsonString = operation.responseString;
        NSData *JSONdata = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        
        NSError *jsonError = nil;
        if (JSONdata != nil) {
            
            NSMutableDictionary *resDic = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
            
            NSArray *arrData = [resDic objectForKey:@"data"];
            
           // NSLog(@"arrData %@",arrData);
            
            for(int i =0;i<[arrData count];i++)
            {
                
                [arrList addObject:[arrData objectAtIndex:i]];
                [inUseArray addObject:[arrData objectAtIndex:i]];

                [tblList reloadData];
            }
            
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"No records found!" delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
            [alert show];
        }
        
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
        
        
        NSString *errStr=[[error userInfo] objectForKey:@"NSLocalizedDescription"];
        if (errStr==Nil) {
            errStr=@"Server not reachable. Check internet connectivity";
        }
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errStr delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
        [alert show];
        
        
        
    }];
    
    [operation start];
    
}

#pragma mark - Search Bar Delegates

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    
    [searchBar resignFirstResponder];
    // Do the search...
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    if ([searchText length] == 0)
    {
        [searchBar performSelector:@selector(resignFirstResponder)
                        withObject:nil
                        afterDelay:0];
    }
    
    [searchData removeAllObjects];// remove all data that belongs to previous search
    //[inUseArray removeAllObjects];
    
    if([searchText isEqualToString:@""] || searchText==nil)
    {
        NSLog(@"ALL DATA DISPLAY");
        
        inUseArray = arrList;
        
        [searchBar resignFirstResponder];
        [tblList reloadData];
        return;
    }
    
    NSInteger counter = 0;
    
    for(int i=0;i<[arrList count];i++)
    {
        
//        cell.lblProduct.text = [dictTemp valueForKey:@"product"];
//        cell.lblReporter.text = [dictTemp valueForKey:@"brand"];
        
        NSLog(@"--  %d",i);
        
        if([[arrList objectAtIndex:i] isEqual:[NSNull null]])
        {
            NSLog(@"No data add");
            
        }
        else
        {
            NSDictionary *dictData = [arrList objectAtIndex:i];
            
            NSString *name = [dictData valueForKey:@"brand"];
            
            if(!name || [name isEqualToString:@""] || [name length]==0)
            {
                NSLog(@"No data");
                NSDictionary *dictData1 = [arrList objectAtIndex:i];

                name = [dictData1 valueForKey:@"brand"];
            }
            
            NSRange r = [name rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            if(r.location != NSNotFound)
            {
                
                NSDictionary *dictData1 = [arrList objectAtIndex:i];

                if(![searchData containsObject:dictData1])
                {
                    [searchData addObject:dictData1];
                }                NSLog(@"dictData--%@",dictData1);
                
            }
            
            NSString *product = [dictData valueForKey:@"product"];
            
            if(!product || [product isEqualToString:@""] || [product length]==0)
            {
                NSLog(@"No data");
                NSDictionary *dictData1 = [arrList objectAtIndex:i];
                
                product = [dictData1 valueForKey:@"product"];
            }
            
            NSRange rproduct = [product rangeOfString:searchText options:NSCaseInsensitiveSearch];
            
            if(rproduct.location != NSNotFound)
            {
                
                NSDictionary *dictData1 = [arrList objectAtIndex:i];
                
                if(![searchData containsObject:dictData1])
                {
                    [searchData addObject:dictData1];
                }                NSLog(@"dictData--%@",dictData1);
                
            }

            
            counter++;
        }
    }
    
    inUseArray = searchData.mutableCopy;

    if([inUseArray count] >0)
    {
        [tblList reloadData];
    }
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    
    for (UIView *subView in searchBar.subviews) {
        if ([subView isKindOfClass:[UIButton class]]) {
            UIButton *cancelButton = (UIButton*)subView;
            [cancelButton setBackgroundImage:Nil forState:UIControlStateNormal];
            
            [cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
        }
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [searchBar resignFirstResponder];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
