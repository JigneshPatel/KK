//
//  AppDelegate.m
//  BrandReporter
//
//  Created by Gauri Shankar on 19/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "AppDelegate.h"
#import "Constant.h"
#import "DBOperations.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@synthesize arrMyReports,dictRecord;
@synthesize path;
@synthesize dictPlistDealsData,intEditReport;

DBOperations *dbOperationsObject;
NSArray *paths;


+ (UIImage*)getImage:(NSString *)strImageName fromFolder:(NSString *)strFolderName
{
    NSString *documentDirectory=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *imagePath=[documentDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",strImageName]];
    UIImage *image=[UIImage imageWithContentsOfFile:imagePath];
    return image;
}

+ (AppDelegate *)sharedAppDelegate
{
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}


+ (UIStoryboard *)storyBoardType
{
    UIStoryboard *storyboard;
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone)
    {
        //storyboard = [UIStoryboard storyboardWithName:@"Main_iPhone5" bundle:nil];

        ///*
        if (IS_IPHONE_5)
        {   // iPhone 6 and iPhone 6+
            
            // Instantiate a new storyboard object using the storyboard file named Storyboard_iPhone5
            storyboard = [UIStoryboard storyboardWithName:@"Main_iPhone5" bundle:nil];
            
            NSLog(@"loaded iPhone5 Storyboard");
        }
        else if (IS_IPHONE_4S)
        {   // iPhone 3GS, 4, and 4S and iPod Touch 3rd and 4th generation: 3.5 inch screen (diagonally measured)
            
            // Instantiate a new storyboard object using the storyboard file named Storyboard_iPhone4
            storyboard = [UIStoryboard storyboardWithName:@"Main_iPhone5" bundle:nil];
            
            NSLog(@"loaded iPhone4 Storyboard");
        }
        else if (IS_IPHONE_6)
        {   // iPhone 3GS, 4, and 4S and iPod Touch 3rd and 4th generation: 3.5 inch screen (diagonally measured)
            
            // Instantiate a new storyboard object using the storyboard file named Storyboard_iPhone4
            storyboard = [UIStoryboard storyboardWithName:@"Main_iPhone5" bundle:nil];
            
            NSLog(@"loaded Main_iPhone6 Storyboard");
        }
        else if (IS_IPHONE_6P)
        {   // iPhone 3GS, 4, and 4S and iPod Touch 3rd and 4th generation: 3.5 inch screen (diagonally measured)
            
            // Instantiate a new storyboard object using the storyboard file named Storyboard_iPhone4
            storyboard = [UIStoryboard storyboardWithName:@"Main_iPhone5" bundle:nil];
            
            NSLog(@"loaded Main_iPhone6P Storyboard");
        }
         
        // */
        
        
    }
    
    
    return storyboard;
}

#pragma mark-
#pragma mark DB Creation

-(void)DBCreation
{
    paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSLog(@"paths Appdelegate %@",paths);
    dbOperationsObject = [DBOperations dbOperationsObject];
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    NSString *str = [defaults valueForKey:kLoggedInUserId];
    
    if ([str length] == 0)
    {
        
        [defaults setValue:@"" forKey:kLoggedInUserId];
    }
    
    // Override point for customization after application launch.
    intEditReport= 0;
    
    [self DBCreation];

    self.dictPlistDealsData=[[NSMutableDictionary alloc]initWithContentsOfFile:path];

    self.manager = [[CLLocationManager alloc] init];
    self.manager.delegate = self;
    
    // Check for iOS 8. Without this guard the code will crash with "unknown selector" on iOS 7.
    
    
    if ([self.manager respondsToSelector:@selector(requestAlwaysAuthorization)])
    {
        [self.manager requestAlwaysAuthorization];
    }
    
    [self.manager startUpdatingLocation];
    
    self.AD_user_uid=[[NSMutableString alloc]init];

    arrMyReports = [[NSMutableArray alloc]init];
    dictRecord = [[NSMutableDictionary alloc] init];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    SlideMenu *menuVC = [[SlideMenu alloc] init];
    UINavigationController *menuNavigationController = [[UINavigationController alloc] initWithRootViewController:menuVC];
    
    UIViewController *viewController;
    
    if([[[NSUserDefaults standardUserDefaults] valueForKey:kLoggedInUserId] length]>0)
    {
        NSLog(@"Already logged in");
        viewController =[[AppDelegate storyBoardType] instantiateViewControllerWithIdentifier:@"MyReportsVCId"];

    }
    else
    {
        NSLog(@"Start logged in");
        viewController =[[AppDelegate storyBoardType] instantiateViewControllerWithIdentifier:@"ViewControllerId"];


    }


    
    UINavigationController *navController1 = [[UINavigationController alloc] initWithRootViewController:viewController];
    
    NVSlideMenuController *slideMenuVC = [[NVSlideMenuController alloc] initWithMenuViewController:menuNavigationController andContentViewController:navController1];
    
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    [self.window setBackgroundColor:[UIColor whiteColor]];

    self.window.rootViewController = slideMenuVC;
    [self.window makeKeyAndVisible];
    
    return YES;
}


-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status) {
        case kCLAuthorizationStatusNotDetermined:
        case kCLAuthorizationStatusRestricted:
        case kCLAuthorizationStatusDenied:
        {
            // do some error handling
        }
            break;
        default:{
            [self.manager startUpdatingLocation];
        }
            break;
    }
}


- (CLLocationManager *)manager {
    
    if (!_manager) {
        _manager = [[CLLocationManager alloc]init];
        _manager.delegate = self;
        _manager.desiredAccuracy = kCLLocationAccuracyBest;
        
        //set the amount of metres travelled before location update is made
    }
    return _manager;
}



- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    
    _cLocation = [locations lastObject];
    
    NSNumber *lat = [NSNumber numberWithDouble:_cLocation.coordinate.latitude];
    NSNumber *lon = [NSNumber numberWithDouble:_cLocation.coordinate.longitude];

    NSDictionary *userLocation=@{@"lat":lat,@"long":lon};
    
    [[NSUserDefaults standardUserDefaults] setObject:userLocation forKey:@"userLocation"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self.manager startUpdatingLocation];
    
}



- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
