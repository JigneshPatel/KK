//
//  SurveyQuestionViewController.m
//  BrandReporter
//
//  Created by Gauri Shankar on 24/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import "SurveyQuestionViewController.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "Constant.h"
#import "QuestionTableViewCell.h"

@interface SurveyQuestionViewController ()
{
    IBOutlet UITableView *tblList;
    NSMutableArray *arrList;
}

@end

@implementation SurveyQuestionViewController

@synthesize dictData;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}


- (IBAction)backButtonAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.navigationController setNavigationBarHidden:YES];
    
    
    arrList = [[NSMutableArray alloc] init];
    
    [self getSurveyQ];
    
}

#pragma mark API

-(void)getSurveyQ
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Loading....", nil);
    
    NSURL *url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"%@&&Survey_name=%@",KURLGetSurveyQuestion,dictData[@"Survey Name"]]];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         [arrList removeAllObjects];
         
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         NSLog(@"success: %@", operation.responseString);
         
         NSString *jsonString = operation.responseString;
         NSData *JSONdata = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
         
         NSError *jsonError = nil;
         if (JSONdata != nil) {
             
             NSMutableDictionary *DiccL = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
             
             NSLog(@"Dicc: %@", DiccL);
             
             
             if ([[DiccL objectForKey:@"result"] intValue] ==1)
             {
                 
                 arrList = [DiccL objectForKey:@"response"];
                 
                 [tblList reloadData];
             }
             else
             {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[DiccL objectForKey:@"msg"] delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
                 [alert show];
             }
         }
         else
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"No records found!" delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
             [alert show];
         }
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         
         NSString *errStr=[[error userInfo] objectForKey:@"NSLocalizedDescription"];
         if (errStr==Nil) {
             errStr=@"Server not reachable. Check internet connectivity";
         }
         
         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errStr delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
         [alert show];
         
     }];
    
    [operation start];
    
}

-(void)submitSurvey
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Loading....", nil);
    
    NSURL *url = [[NSURL alloc] initWithString:KURLSubmitSurvey];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         [arrList removeAllObjects];
         
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         NSLog(@"success: %@", operation.responseString);
         
         NSString *jsonString = operation.responseString;
         NSData *JSONdata = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
         
         NSError *jsonError = nil;
         if (JSONdata != nil) {
             
             NSMutableDictionary *DiccL = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:&jsonError];
             
             NSLog(@"Dicc: %@", DiccL);
             
             
             if ([[DiccL objectForKey:@"result"] intValue] ==1)
             {
                 
                 arrList = [DiccL objectForKey:@"response"];
                 
                 [tblList reloadData];
             }
             else
             {
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"No records found!" delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
                 [alert show];
             }
         }
         else
         {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"No records found!" delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
             [alert show];
         }
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         
         [MBProgressHUD hideHUDForView:self.view animated:YES];
         
         NSString *errStr=[[error userInfo] objectForKey:@"NSLocalizedDescription"];
         if (errStr==Nil) {
             errStr=@"Server not reachable. Check internet connectivity";
         }
         
         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:errStr delegate:nil cancelButtonTitle:@"Okay!" otherButtonTitles: nil];
         [alert show];
         
     }];
    
    [operation start];
    
}

#pragma mark Table View Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 115;
    
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [arrList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"QuestionTableViewCell";
    
    QuestionTableViewCell *cell = (QuestionTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib;
        
        if (IS_IPHONE_5)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"QuestionTableViewCell" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"QuestionTableViewCell" owner:self options:nil];
            
        }
        else if (IS_IPHONE_6P)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"QuestionTableViewCell" owner:self options:nil];
            
        }else if (IS_IPHONE_4S)
        {
            nib = [[NSBundle mainBundle] loadNibNamed:@"QuestionTableViewCell" owner:self options:nil];
            
        }
        
        cell = [nib objectAtIndex:0];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    
    NSDictionary *dictTemp = [arrList objectAtIndex:indexPath.row];
    
    cell.lblQuestion.text = [NSString stringWithFormat:@"%ld. %@",indexPath.row+1,dictTemp[@"Question"]];
    
    cell.txtAns.tag = indexPath.row;
    cell.txtAns.text = @"";
       
    tblList.separatorColor = [UIColor clearColor];
    
    
    return cell;
}


-(IBAction)submitAns:(id)sender
{
    NSLog(@"submitAns");
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
