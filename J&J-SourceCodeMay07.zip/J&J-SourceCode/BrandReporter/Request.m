//
//  Request.m
//  PASSENGER
//
//  Created by vikas on 24/08/15.
//  Copyright (c) 2015 Avigma. All rights reserved.
//

#import "Request.h"
#import "Constant.h"

#define TimeStamp [NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970] * 1000]
@implementation Request

-(void)createConnection:(NSMutableURLRequest *)postRequest{
    _urlConnecction = [[NSURLConnection alloc]initWithRequest:postRequest delegate:self];
    if(_urlConnecction)
    {
        _webData = [NSMutableData data];
    }
    else
    {
        NSLog(@"theConnection is NULL");
    }
    [_urlConnecction start];
}
#pragma -mark SignUp using multipart

//[reqObj signUpWithMultipart:txtEmail.text name:txtUserName.text password:txtPwd.text profilePic:UIImagePNGRepresentation(imgPic.image)];

-(void)signUpWithMultipart:(NSString *)email name:(NSString *)name password:(NSString *)password profilePic:(NSData *)profilePic
{

    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://brandreporter.co/webservice/brandreporter.php?action=editpro"]];
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:45.0];
    [postRequest setValue:@"900" forHTTPHeaderField:@"Keep-Alive"];
    [postRequest setValue:@"keep-alive" forHTTPHeaderField:@"Connection"];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
    
    NSMutableData *body = [NSMutableData data];
    
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [postRequest addValue:contentType forHTTPHeaderField:@"Content-Type"];
    //name=%@&surname=%@&email=%@&pass=%@&profilepic=%@&dob=%@&nationality=%@&gender=%@&deviceToken=%@
    
    
    //UserId
    if (name.length>0) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        NSString *str=@"Content-Disposition: form-data; name=\"userid\"\r\n\r\n";
        [body appendData:[[NSString stringWithString:str] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] valueForKey:kLoggedInUserId]] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    
    if (email.length>0) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        NSString *str=@"Content-Disposition: form-data; name=\"email\"\r\n\r\n";
        [body appendData:[[NSString stringWithString:str] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@",email] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    /*
    if (password.length>0) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        NSString *str=@"Content-Disposition: form-data; name=\"password\"\r\n\r\n";
        [body appendData:[[NSString stringWithString:str] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@",password] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    */
    
        NSString *imageName = TimeStamp;
    
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        NSString *str=@"Content-Disposition: form-data; name=\"image\"\r\n\r\n";
        [body appendData:[[NSString stringWithString:str] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"%@.png",imageName] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];

    
    if (profilePic != nil && profilePic.length>0) {
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"uploaded_file\"; filename=\"%@.png\"\r\n",imageName] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[NSData dataWithData:profilePic]];
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    [postRequest setHTTPBody:body];
    [self createConnection:postRequest];
}

//SignUp
-(void)signUp:(NSString *)name surname:(NSString *)surname email:(NSString *)email password:(NSString *)password profilePic:(NSString *)profilePic dob:(NSString *)dob nationality:(NSString *)nationality gender:(NSString*)gender withDeviceToken:(NSString*)tokken
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.support-4-pc.com/clients/passenger/subscriber.php?action=register"]];
    NSString *parameterStringInRequestBody =[NSString stringWithFormat:@"name=%@&surname=%@&email=%@&pass=%@&profilepic=%@&dob=%@&nationality=%@&gender=%@&deviceToken=%@",name,surname,email,password,profilePic,dob,nationality,gender,tokken];
    NSData *POSTData = [parameterStringInRequestBody dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:url];
    [postRequest setHTTPBody:POSTData];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [self createConnection:postRequest]; 
}
//Login
-(void)loginWithUserName:(NSString *)userName withPassword:(NSString *)password{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.support-4-pc.com/clients/passenger/subscriber.php?action=login"]];
    NSString *parameterStringInRequestBody =[NSString stringWithFormat:@"email=%@&pass=%@",userName,password];
    NSData *POSTData = [parameterStringInRequestBody dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:url];
    [postRequest setHTTPBody:POSTData];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [self createConnection:postRequest];
}

//Forgot password
-(void)resetPasswordWithEmail:(NSString *)email
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.support-4-pc.com/clients/passenger/subscriber.php?action=forgotpass"]];
    NSString *parameterStringInRequestBody =[NSString stringWithFormat:@"email=%@",email];
    NSData *POSTData = [parameterStringInRequestBody dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:url];
    [postRequest setHTTPBody:POSTData];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [self createConnection:postRequest];
}


//Edit Profile
-(void)editProfile:(NSString *)name surname:(NSString *)surname email:(NSString *)email profilePic:(NSString *)profilePic dob:(NSString *)dob nationality:(NSString *)nationality  withDeviceToken:(NSString*)tokken
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.support-4-pc.com/clients/passenger/subscriber.php?action=editpro"]];
    NSString *parameterStringInRequestBody =[NSString stringWithFormat:@"name=%@&surname=%@&email=%@&profilepic=%@&dob=%@&nationality=%@&deviceToken=%@",name,surname,email,profilePic,dob,nationality,tokken];
    NSData *POSTData = [parameterStringInRequestBody dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:url];
    [postRequest setHTTPBody:POSTData];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [self createConnection:postRequest];
}

//create event
-(void)createEvent:(NSString *)event_name event_location:(NSString *)event_location event_date:(NSString *)event_date event_type:(NSString *)event_type event_image:(NSString *)event_image additional_images:(NSString *)additional_images event_description:(NSString *)event_description event_additional_info
                  :(NSString *)event_additional_info
  withDeviceToken:(NSString*)tokken
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.support-4-pc.com/clients/passenger/subscriber.php?action=Create_Event"]];
    NSString *parameterStringInRequestBody =[NSString stringWithFormat:@"event_name=%@&event_location=%@&event_date=%@&event_type=%@&event_image=%@&additional_images=%@&event_description=%@&event_additional_info=%@&deviceToken=%@",event_name,event_location,event_date,event_type,event_image,additional_images,event_description,event_additional_info,tokken];
    NSData *POSTData = [parameterStringInRequestBody dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:url];
    [postRequest setHTTPBody:POSTData];
    [postRequest setHTTPMethod:@"POST"];
    [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [self createConnection:postRequest];
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [_webData setLength: 0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    _urlConnecction=nil;
    if (_delegate != nil && [_delegate respondsToSelector:@selector(getError)]) {
        [_delegate getError];
    }
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"DONE. Received Bytes: %lu", (unsigned long)[_webData length]);
    NSString *jsonString = [[NSString alloc] initWithData:_webData encoding:NSUTF8StringEncoding];
    NSLog(@"jsonString = %@",jsonString);
    id responseData = [NSJSONSerialization JSONObjectWithData:_webData options:NSJSONReadingMutableContainers error:nil];;
    _urlConnecction=nil;
    NSLog(@"response = %@",[responseData description]);
    if (responseData != nil) {
        if (_delegate != nil && [_delegate respondsToSelector:@selector(getResult:)]) {
            [_delegate getResult:responseData];
        }
    }
    else
        {
        if (_delegate != nil && [_delegate respondsToSelector:@selector(getError)]) {
            [_delegate getError];
        }
        }
}
-(void)dealloc
{
    _delegate = nil;
}


@end
