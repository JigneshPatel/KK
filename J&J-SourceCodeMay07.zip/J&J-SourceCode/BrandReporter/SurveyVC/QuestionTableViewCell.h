//
//  QuestionTableViewCell.h
//  BrandReporter
//
//  Created by Gauri Shankar on 24/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuestionTableViewCell : UITableViewCell

@property (weak, nonatomic)     IBOutlet UILabel *lblQuestion;
@property (weak, nonatomic)     IBOutlet UITextView *txtAns;

@end
