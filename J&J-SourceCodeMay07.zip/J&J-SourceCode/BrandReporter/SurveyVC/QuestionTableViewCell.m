//
//  QuestionTableViewCell.m
//  BrandReporter
//
//  Created by Gauri Shankar on 24/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import "QuestionTableViewCell.h"

@implementation QuestionTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
