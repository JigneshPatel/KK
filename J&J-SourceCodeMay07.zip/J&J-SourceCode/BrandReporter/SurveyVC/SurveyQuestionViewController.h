//
//  SurveyQuestionViewController.h
//  BrandReporter
//
//  Created by Gauri Shankar on 24/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SurveyQuestionViewController : UIViewController
{
    NSDictionary *dictData;
}

@property (strong, nonatomic) NSDictionary *dictData;

@end
