//
//  SurveyViewController.h
//  BrandReporter
//
//  Created by Gauri Shankar on 23/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SurveyViewController : UIViewController

@end
