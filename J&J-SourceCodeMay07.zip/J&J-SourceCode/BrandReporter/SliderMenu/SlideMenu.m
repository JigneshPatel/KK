//
//  SlideMenu.m


#import "SlideMenu.h"
#import "Constant.h"
#import "MyReportsVC.h"
#import "NVSlideMenuController.h"
#import "MyAccountVC.h"
#import "KnowledgeVC.h"
#import "TeamTrackerVC.h"
#import "HotAlertsVC.h"
#import "TeamReportsVC.h"
#import "igViewController.h"
#import "ViewController.h"
#import "NotificationsViewController.h"
#import "SurveyViewController.h"
#import "DraftViewController.h"


@interface SlideMenu ()<UIGestureRecognizerDelegate>
{
    NSMutableArray *array_menuitems;
    IBOutlet UILabel *lblName;
}

@end

@implementation SlideMenu
AppDelegate *delegate;

@synthesize tabelview_out;


- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


#pragma mark FOR LEFT MENU ITEM

- (void)handlePan {
    
    if (!look)
    {
        [self.slideMenuController openMenuAnimated:YES completion:nil];
        
    }
    
    else
    {
        [self.slideMenuController closeMenuAnimated:YES completion:nil];
    }
    
    
    look=!look;
    
}


- (void)viewDidLoad
{
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan)];
    [panGesture setDelegate:self];
    
    /* set no of touch for pan gesture*/
    
    [panGesture setMaximumNumberOfTouches:1];
    
    /*  Add gesture to your image. */
    
    [self.view addGestureRecognizer:panGesture];
    
    
    self.slideMenuController.panGestureEnabled = YES;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    delegate= (AppDelegate *)[[UIApplication sharedApplication]delegate];

    self.title=@"Welcome!";
    
    
    lblName.text = [[NSUserDefaults standardUserDefaults] valueForKey:kLoggedInUserName];
    [self.navigationController setNavigationBarHidden:YES];
    
    array_menuitems = [[NSMutableArray alloc] init];
    
    //Static Data
    
    
    NSDictionary *dictData = @{@"title" : @"Create New Report", @"image" : @"createicn.png"};
    [array_menuitems addObject:dictData];
    
    dictData = @{@"title" : @"My Reports", @"image" : @"MyReports.png"};
    [array_menuitems addObject:dictData];
    
    dictData = @{@"title" : @"My Survey", @"image" : @"survey-menu.png"};
    [array_menuitems addObject:dictData];

    dictData = @{@"title" : @"Draft", @"image" : @"draft-menu.png"};
    [array_menuitems addObject:dictData];

    dictData = @{@"title" : @"Notifications", @"image" : @"notification-menu.png"};
    [array_menuitems addObject:dictData];
    
    dictData = @{@"title" : @"Profile", @"image" : @"profile-menu.png"};
    [array_menuitems addObject:dictData];

    dictData = @{@"title" : @"Logout", @"image" : @"logout-menu.png"};
    [array_menuitems addObject:dictData];
    
   
    [tabelview_out setBackgroundColor:[UIColor colorWithRed:51.0/255.0f green:51.0/255.0f blue:51.0/255.0f alpha:1.0]];
    [tabelview_out reloadData];
    
}


#pragma mark Table View Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 60;
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

// for no. of rows in section

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:
(NSInteger)section{
    return [array_menuitems count];
}


//for each cell in section

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:
(NSIndexPath *)indexPath{
    
    //initalization of cell
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                             nil];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:
                UITableViewCellStyleSubtitle reuseIdentifier:nil];
    }
    
    //for cell label
    
    NSDictionary *dict = [array_menuitems objectAtIndex:indexPath.row];
    
    cell.textLabel.font = [UIFont systemFontOfSize:17];
    [cell.textLabel setText:dict[@"title"]];
    [cell.textLabel setTextColor:[UIColor whiteColor]];
    [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
    
//    cell.detailTextLabel.font = [UIFont systemFontOfSize:14];
//    [cell.detailTextLabel setText:dict[@"subtitle"]];
//    [cell.detailTextLabel setTextColor:[UIColor whiteColor]];

    [cell.imageView setImage:[UIImage imageNamed:dict[@"image"]]];

    
    //hoverbg@2x.png
    //cell.selectionStyle = UITableViewCellSelectionStyleGray;
    
    
    UIView *bgColorView = [[UIView alloc] init];
    bgColorView.backgroundColor = [UIColor colorWithRed:64.0/255.0f green:200.0/255.0f blue:214.0/255.0f alpha:1.0];
    [cell setSelectedBackgroundView:bgColorView];
   
    
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    if (indexPath.row==0)//Camera
    {
        delegate.intEditReport = 0;

        UIStoryboard *storyboard = [AppDelegate storyBoardType];
        igViewController *objView = (igViewController*)[storyboard instantiateViewControllerWithIdentifier:@"igViewControllerId"];
        
        UINavigationController *nav =[[UINavigationController alloc] initWithRootViewController:objView];
        [self.slideMenuController closeMenuBehindContentViewController:nav animated:YES completion:nil];
        
//        igViewController *objVC = [[igViewController alloc] init];
//        
//        [self.navigationController pushViewController:objVC animated:YES];
//        objVC = nil;
    }
    else if (indexPath.row==1)//MyReport
    {
        UIStoryboard *storyboard = [AppDelegate storyBoardType];
        MyReportsVC *objView = (MyReportsVC*)[storyboard instantiateViewControllerWithIdentifier:@"MyReportsVCId"];
        
        UINavigationController *nav =[[UINavigationController alloc] initWithRootViewController:objView];
        [self.slideMenuController closeMenuBehindContentViewController:nav animated:YES completion:nil];
    }
    
    else if (indexPath.row==2) {//My Survey
        
        UIStoryboard *storyboard = [AppDelegate storyBoardType];
        SurveyViewController *objView = (SurveyViewController*)[storyboard instantiateViewControllerWithIdentifier:@"SurveyViewControllerId"];
        
        UINavigationController *nav =[[UINavigationController alloc] initWithRootViewController:objView];
        [self.slideMenuController closeMenuBehindContentViewController:nav animated:YES completion:nil];
        
    }

    else if (indexPath.row==3) {//Draft
        
        UIStoryboard *storyboard = [AppDelegate storyBoardType];
        DraftViewController *objView = (DraftViewController*)[storyboard instantiateViewControllerWithIdentifier:@"DraftViewControllerId"];
        
        UINavigationController *nav =[[UINavigationController alloc] initWithRootViewController:objView];
        [self.slideMenuController closeMenuBehindContentViewController:nav animated:YES completion:nil];
        
    }

    //
    else if (indexPath.row==4) {//Notify
        
        UIStoryboard *storyboard = [AppDelegate storyBoardType];
        NotificationsViewController *objView = (NotificationsViewController*)[storyboard instantiateViewControllerWithIdentifier:@"NotificationsViewControllerId"];
        
        UINavigationController *nav =[[UINavigationController alloc] initWithRootViewController:objView];
        [self.slideMenuController closeMenuBehindContentViewController:nav animated:YES completion:nil];
        
    }
    else if (indexPath.row==5) {//Profile
        
        UIStoryboard *storyboard = [AppDelegate storyBoardType];
        MyAccountVC *objView = (MyAccountVC*)[storyboard instantiateViewControllerWithIdentifier:@"MyAccountVCId"];
        
        UINavigationController *nav =[[UINavigationController alloc] initWithRootViewController:objView];
        [self.slideMenuController closeMenuBehindContentViewController:nav animated:YES completion:nil];
        
    }
    else if (indexPath.row==6) {//Logout
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Are you sure you want to logout?" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"Yes",@"No", nil];
        alert.tag = 11;
        [alert show];
        
    }
}


#pragma mark Alert View Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 11)
    {
        
        if (buttonIndex == 0)
        {
            
            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:kLoggedInUserId];
            [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:kLoggedInUserEmail];
            [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:kLoggedInUserName];
        
            ViewController *objRegisterView = (ViewController*)[[AppDelegate storyBoardType] instantiateViewControllerWithIdentifier:@"ViewControllerId"];
            
            UINavigationController *nav =[[UINavigationController alloc] initWithRootViewController:objRegisterView];
            [self.slideMenuController closeMenuBehindContentViewController:nav animated:YES completion:nil];
            self.slideMenuController.panGestureEnabled = NO;
            
        }
    }
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
