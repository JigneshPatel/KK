//
//  CreatReportVC.m
//  BrandReporter
//
//  Created by Gauri Shankar on 24/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "CreatReportVC.h"
#import "NVSlideMenuController.h"
#import "MapSearchViewController.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "DBOperations.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "UITextField+Shake.h"

#define MAX_LENGTH 30

@interface CreatReportVC ()<UITextFieldDelegate,UITextViewDelegate,UIScrollViewDelegate>
{
    UIStoryboard *storyboard;
    AppDelegate *delegate;
    IBOutlet UITextField *txtMft,*txtBrand,*txtProd,*txtSize,*txtBarCode;
    IBOutlet UITextView *txtViewComment;
    IBOutlet UIImageView *imgPic;
}

@end

@implementation CreatReportVC

@synthesize scrollView;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

#pragma mark FOR LEFT MENU ITEM

- (IBAction)backButtonAction:(id)sender {
    
   
        [txtViewComment resignFirstResponder];
        [txtSize resignFirstResponder];
        [txtProd resignFirstResponder];
        [txtMft resignFirstResponder];
        [txtBrand resignFirstResponder];
        
      
    [self.navigationController popViewControllerAnimated:YES];
    
}


- (void)viewDidLoad
{
    delegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];

    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [scrollView contentSizeToFit];

   
    txtViewComment.layer.cornerRadius=10;
    
    imgPic.layer.cornerRadius = imgPic.frame.size.width / 2;
    imgPic.clipsToBounds = YES;
//    imgPic.layer.borderWidth = 3.0f;
//    imgPic.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    NSLog(@"delegate.dictRecord Image %@",[delegate.dictRecord valueForKey:@"report_image"]);
    
    NSArray *arrImg = [delegate.dictRecord valueForKey:@"report_image"];
    
    if([arrImg count]>0)
    {
        imgPic.image = [[arrImg objectAtIndex:0] valueForKey:@"Img"];
    }
    else
    {
        imgPic.image = [UIImage imageNamed:@"no_image.png"];
    }
    txtBarCode.text = [delegate.dictRecord valueForKey:@"BarCode"];
    
   [self performSelector:@selector(InsertView)  withObject:nil afterDelay:1.0];
    
    if(delegate.intEditReport>0)
    {
        
        NSDictionary *dict=  delegate.dictRecord;
    
        txtBarCode.text = [dict valueForKey:@"barcode"];
        [txtViewComment setText:[dict valueForKey:@"comment"]];
        [txtSize setText:[dict valueForKey:@"size"]];
        [txtProd setText:[dict valueForKey:@"product"]];
        [txtMft setText:[dict valueForKey:@"manufacturer"]];
        [txtBrand setText:[dict valueForKey:@"brand"]];

        //NSLog(@"Image %@",[dict valueForKey:@"Image"]);

    }
    else
    {
        if([[delegate.dictRecord valueForKey:@"BarCode"] length]>0)
        {
            [self barCodeValidation];
        }
    }
    
}

#pragma mark VerifyBarcode API

-(void)barCodeValidation
{
    
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = NSLocalizedString(@"Searching EAN/QR Database", nil);
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:KURLBarCode]];
    
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:60];
    [request setHTTPMethod:@"POST"];
    
    NSString *boundary = @"unique-consistent-string";
    
    // set Content-Type in HTTP header
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
    
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=%@\r\n\r\n", @"user_name"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n",[defaults valueForKey:kLoggedInUserName]] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // add params (all params are strings)
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=%@\r\n\r\n", @"barcode"] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n",[delegate.dictRecord valueForKey:@"BarCode"]] dataUsingEncoding:NSUTF8StringEncoding]];
    
   
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set the content-length
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue currentQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         if(data.length > 0)
         {
             //success
             NSLog(@"success");
             
             [MBProgressHUD hideHUDForView:self.view animated:YES];
             
             NSError *jsonError = nil;
             if (data != nil) {
                 
                 NSMutableDictionary *resDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&jsonError];
                 
                 if ([[resDic objectForKey:@"result"] intValue] ==0)
                 {
                     //UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                     //[alert show];
                 }
                 else
                 {
                     
                     NSArray *arr = [resDic objectForKey:@"response"];
                     
                     NSDictionary *dict = [arr objectAtIndex:0];
                     
                     NSLog(@"success %@",dict);
                     delegate.dictRecord = (NSMutableDictionary*)dict;
                     
                 }
                 
             } else {
                 
                 
             }
             
             /*
              
              */
         }
     }];
}

-(void)InsertView
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];

}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView1 willDecelerate:(BOOL)decelerate
{
    CGPoint offset = scrollView1.contentOffset;
    [scrollView1 setContentOffset:offset animated:NO];
    
    
}


- (IBAction)newButtonAction:(id)sender
{
    if([txtBarCode.text length] ==0)
    {
        txtBarCode.layer.borderWidth = 2.0f;
        txtBarCode.layer.borderColor=[[UIColor redColor]CGColor];
        [txtBarCode shake:10 withDelta:5 speed:0.03 shakeDirection:ShakeDirectionVertical completion:nil];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please enter bar code!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        return;

    }
    else if([txtMft.text length] ==0)
    {
        txtMft.layer.borderWidth = 2.0f;

        txtMft.layer.borderColor=[[UIColor redColor]CGColor];
        [txtMft shake:10 withDelta:5 speed:0.03 shakeDirection:ShakeDirectionVertical completion:nil];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please enter manufacture!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        return;

    }
    else if([txtBrand.text length] ==0)
    {
        txtBrand.layer.borderWidth = 2.0f;

        txtBrand.layer.borderColor=[[UIColor redColor]CGColor];
        [txtBrand shake:10 withDelta:5 speed:0.03 shakeDirection:ShakeDirectionVertical completion:nil];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please enter brand!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        return;

    }
    else if([txtProd.text length] ==0)
    {
        txtProd.layer.borderWidth = 2.0f;

        txtProd.layer.borderColor=[[UIColor redColor]CGColor];
        [txtProd shake:10 withDelta:5 speed:0.03 shakeDirection:ShakeDirectionVertical completion:nil];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please enter product!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        return;

    }
    else if([txtSize.text length] ==0)
    {
        txtSize.layer.borderWidth = 2.0f;

        txtSize.layer.borderColor=[[UIColor redColor]CGColor];
        [txtSize shake:10 withDelta:5 speed:0.03 shakeDirection:ShakeDirectionVertical completion:nil];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please enter size!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        return;

    }
    else if([txtViewComment.text length] ==0)
    {
        txtViewComment.layer.borderWidth = 2.0f;

        txtViewComment.layer.borderColor=[[UIColor redColor]CGColor];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please enter comment!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        return;

    }
    else
    {
        [delegate.dictRecord setValue:txtBarCode.text forKey:@"BarCode"];
        [delegate.dictRecord setValue:txtMft.text forKey:@"Manufacture"];
        [delegate.dictRecord setValue:txtBrand.text forKey:@"Brand"];
        [delegate.dictRecord setValue:txtProd.text forKey:@"Product"];
        [delegate.dictRecord setValue:txtSize.text forKey:@"Size"];
        [delegate.dictRecord setValue:txtViewComment.text forKey:@"Comment"];
        
        storyboard = [AppDelegate storyBoardType];
        
        MapSearchViewController *objVC = (MapSearchViewController*)[storyboard instantiateViewControllerWithIdentifier:@"MapSearchViewControllerId"];
        [self.navigationController pushViewController:objVC animated:YES];
        objVC = nil;
    }
}

#pragma mark Text View Delegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [txtViewComment setTextColor:[UIColor blackColor]];
    
    textView.text = @"";
    [textView becomeFirstResponder];

}

- (BOOL) textView: (UITextView*) textView
shouldChangeTextInRange: (NSRange) range
  replacementText: (NSString*) text
{
    if ([text isEqualToString:@"\n"]) {

        [textView resignFirstResponder];
        return NO;
    }
    
    if (textView.text.length >= 100 && range.length == 0)
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Maximum limit excceded!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO; // return NO to not change text
    }
    
    return YES;
}

-(void)textViewDidEndEditing:(UITextView *)textView
{

    [textView resignFirstResponder];
    
}

#pragma mark Text Field Delegate

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    
    return YES;

}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField == txtBarCode)
    {
   
        NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        
        if ([string rangeOfCharacterFromSet:nonNumberSet].location != NSNotFound)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please enter numeric only!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];

            return NO;
        }
        
        
    }
    
    if (textField.text.length >= MAX_LENGTH && range.length == 0)
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Maximum limit excceded!" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        
        return NO; // return NO to not change text
    }
   

    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
