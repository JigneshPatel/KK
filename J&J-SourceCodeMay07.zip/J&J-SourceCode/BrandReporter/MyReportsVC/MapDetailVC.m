//
//  MapDetailVC.m
//  BrandReporter
//
//  Created by Gauri Shankar on 08/08/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "MapDetailVC.h"

@interface MapDetailVC ()
{
    NSString *strLat,*strLong;
    
}

@property (strong, nonatomic) CLLocationManager *manager;

-(IBAction)backButton:(id)sender;

@end

@implementation MapDetailVC

@synthesize strLatLong;


- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    // in your program you will likely need to use custom annotation objects
    
    if([strLatLong length]>0)
    {
        
    
    NSArray *myWords = [strLatLong componentsSeparatedByString:@","];
    
    NSLog(@"strLatLong %@ myWords %@",strLatLong,myWords);

    strLat = [myWords objectAtIndex:0];
    strLong = [myWords objectAtIndex:1];
    
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake([[myWords objectAtIndex:0] doubleValue],
                                                                   [[myWords objectAtIndex:1] doubleValue]);
    

    MKCoordinateRegion mapRegion;
            
        mapRegion.span.latitudeDelta = 0.005;
        mapRegion.span.longitudeDelta = 0.005;
        
    mapRegion.center = coordinate;
        [mapview setDelegate:self];

    [mapview setRegion:mapRegion animated:YES];
    mapRegion = [mapview regionThatFits:mapRegion];
        
        [mapview  setMapType:MKMapTypeHybrid];
        [self addAnnotation];

    }
    else
    {
        mapview.showsUserLocation=YES;
    }
    
}

-(void)addAnnotation
{

    MKPointAnnotation *ann = [[MKPointAnnotation alloc]init];
    ann.coordinate = CLLocationCoordinate2DMake([strLat floatValue], [strLong floatValue]);
    [mapview addAnnotation:ann];
    ann=nil;
    
    
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 800, 800);
    
    if ( (region.center.latitude >= -90) && (region.center.latitude <= 90) && (region.center.longitude >= -180) && (region.center.longitude <= 180))
    {
        [mapview setRegion:[mapview regionThatFits:region] animated:YES];
    }
    
    
}

#pragma mark -
#pragma mark MKMapView delegate

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    //
    
    static NSString* AnnotationIdentifier = @"Annotation";
    MKPinAnnotationView *pinView = (MKPinAnnotationView *)[mapview dequeueReusableAnnotationViewWithIdentifier:AnnotationIdentifier];
    
    if(annotation != mapView.userLocation) {
        
        MKPinAnnotationView *customPinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:AnnotationIdentifier];
        customPinView.animatesDrop = YES;

        customPinView.image = [UIImage imageNamed:@"new_markerv1.png"];
        customPinView.canShowCallout = YES;
        customPinView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        return customPinView;
        
    }
    else {
        
        pinView.annotation = annotation;
        return pinView;
        
    }
    
}

#pragma mark Custom Button Action

-(IBAction)backButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
