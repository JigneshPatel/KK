//
//  MRDCollectionViewCell.m
//  BrandReporter
//
//  Created by Gauri Shankar on 22/10/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "MRDCollectionViewCell.h"

@implementation MRDCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
