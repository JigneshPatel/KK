//
//  NotificationDetailViewController.m
//  BrandReporter
//
//  Created by Gauri Shankar on 23/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import "NotificationDetailViewController.h"
#import "AppDelegate.h"

#import "AFNetworking.h"
#import "UIImageView+WebCache.h"

@interface NotificationDetailViewController ()
{
    IBOutlet UILabel *lblTitle;
    IBOutlet UITextView *txtView;
    IBOutlet UIImageView *imgProduct;
}
@end

@implementation NotificationDetailViewController

@synthesize dictData;

- (UIStatusBarStyle) preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}


- (IBAction)backButtonAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.navigationController setNavigationBarHidden:YES];

    lblTitle.text = dictData[@"title"];
    txtView.text = dictData[@"message"];
    
   imgProduct.layer.cornerRadius = imgProduct.frame.size.width / 2;
    imgProduct.clipsToBounds = YES;
    
    [imgProduct
     sd_setImageWithURL:[NSURL URLWithString:dictData[@"image"]]
     placeholderImage:[UIImage imageNamed:@"logo.png"]];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    [self.navigationController setNavigationBarHidden:YES];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
