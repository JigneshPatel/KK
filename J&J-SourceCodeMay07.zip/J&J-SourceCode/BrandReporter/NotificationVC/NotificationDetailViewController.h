//
//  NotificationDetailViewController.h
//  BrandReporter
//
//  Created by Gauri Shankar on 23/04/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationDetailViewController : UIViewController
{
    NSDictionary *dictData;
}

@property (strong, nonatomic) NSDictionary *dictData;

@end
