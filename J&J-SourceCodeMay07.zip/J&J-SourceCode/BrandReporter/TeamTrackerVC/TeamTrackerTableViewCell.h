//
//  TeamTrackerTableViewCell.h
//  BrandReporter
//
//  Created by Brahmasys on 23/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TeamTrackerTableViewCell : UITableViewCell

@property (weak, nonatomic)     IBOutlet UIImageView *imgProduct;
@property (weak, nonatomic)     IBOutlet UIButton *btnHist;
@property (weak, nonatomic)     IBOutlet UILabel *lblTitle,*lblDate,*lblTime;
@property (weak, nonatomic)     IBOutlet UIView *viewWhite;
@property (weak, nonatomic)     IBOutlet UITextView *txtAddress;
@end
