//
//  TeamTrackerTableViewCell.m
//  BrandReporter
//
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import "TeamTrackerTableViewCell.h"

@implementation TeamTrackerTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
