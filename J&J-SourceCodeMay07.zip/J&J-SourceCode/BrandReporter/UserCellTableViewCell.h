//
//  UserCellTableViewCell.h
//  WinkChatDemo
//
//  Created by Brahmasys on 27/03/15.
//  Copyright (c) 2015 LS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserCellTableViewCell : UITableViewCell

@property(weak,nonatomic) IBOutlet UIImageView *imgUser;
@property(weak,nonatomic) IBOutlet UILabel *lblFNLN;
@property(weak,nonatomic) IBOutlet UILabel *lblUN,*lblBlock,*lblPrfl,*lblFirst,*lblSecnd;
@property(weak,nonatomic) IBOutlet UIButton *btnAdd,*btnOtherUser;


@end
