//
//  RegisterVCViewController.h
//  BrandReporter
//
//  Created by Gauri Shankar on 19/07/15.
//  Copyright (c) 2015 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Request.h"

#import "TPKeyboardAvoidingScrollView.h"
@class TPKeyboardAvoidingScrollView;

@interface RegisterVCViewController : UIViewController<RequestDelegate>

@property (nonatomic, retain) IBOutlet TPKeyboardAvoidingScrollView *scrollView;

-(IBAction)registerButtonAction:(id)sender;
-(IBAction)cancelButtonAction:(id)sender;

@end
